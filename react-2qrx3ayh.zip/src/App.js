import React from 'react';
import './style.css';
import DashboardTour from './DashboardTour';

export default function App() {
  return <DashboardTour />;
}
